#Write your code below this row 👇
total = 0
for number in range(2, 101, 2):
    total += number 
print(total)