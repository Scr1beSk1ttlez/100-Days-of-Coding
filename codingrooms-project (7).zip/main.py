# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇

# new_two_digit_number = int(two_digit_number)


# print(new_two_digit_number[0] + new_two_digit_number[1])

first_digit = two_digit_number[0]
second_digit = two_digit_number[1]

new_one_digit_number = int(first_digit)
new_two_digit_number = int(second_digit)

print(new_one_digit_number + new_two_digit_number)

