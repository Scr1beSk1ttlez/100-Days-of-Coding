# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

lowercase_name1 = name1.lower()
t1_score = lowercase_name1.count("t") 
r1_score = lowercase_name1.count("r")
u1_score = lowercase_name1.count("u")
e1_score = lowercase_name1.count("e") 
l1_score = lowercase_name1.count("l") 
o1_score = lowercase_name1.count("o") 
v1_score = lowercase_name1.count("v") 
e1_score = lowercase_name1.count("e") 

lowercase_name2 = name2.lower()
t2_score = lowercase_name2.count("t") 
r2_score = lowercase_name2.count("r")
u2_score = lowercase_name2.count("u")
e2_score = lowercase_name2.count("e") 
l2_score = lowercase_name2.count("l") 
o2_score = lowercase_name2.count("o") 
v2_score = lowercase_name2.count("v") 
e2_score = lowercase_name2.count("e") 

true_score = str(t1_score + r1_score + u1_score + e1_score + t2_score + r2_score + u2_score + e2_score)
love_score = str(l1_score + o1_score + v1_score + e1_score + l2_score + o2_score + v2_score + e2_score)
total_score = int(true_score + love_score)

if total_score < 10 or total_score > 90:
    print(f"Your score is {total_score}, you go together like coke and mentos.")
elif total_score > 40 and total_score < 50:
    print(f"Your score is {total_score}, you are alright together.")
else:
    print(f"Your score is {total_score}")

