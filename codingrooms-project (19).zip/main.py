print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
''')
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.") 

#https://www.draw.io/?lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&title=Treasure%20Island%20Conditional.drawio#Uhttps%3A%2F%2Fdrive.google.com%2Fuc%3Fid%3D1oDe4ehjWZipYRsVfeAx2HyB7LCQ8_Fvi%26export%3Ddownload

#Write your code below this line 👇

first_move = input("You find the secret cave entrace. As you walk along the dark passage, you encounter two diverging tunnels. Only one leads to the hidden treasure. Which do you take? Type left or right and see your fate! \n").lower()
if first_move == "left":
  second_move = input("You travel down the left passage and soon you begin to hear the dip of water. The tunnel opens up into a large cavern with a lake. On the other side of the lake, you can see another tunnel. You look to your left and there appears to be writing on the walls. Do you swim accross the lake or wait and read the writings? Type swim or wait and see your fate! \n" ).lower()
  if second_move == "wait":
    third_move = input('The writings state, "One door leads to ashes, one leads to claws, and the other leads to sunlight. Pick wisely." You begin to look closely at the wall where the writings are. Eventually, you find a pressure plate in the wall and three doors appear: one blue, one red, and one yellow. Type yellow, blue, or red and see your fate! \n').lower()
    if third_move == "blue":
      print("Burned by fire. GAME OVER")
    elif third_move == "red":
      print("Eaten by beasts. GAME OVER")
    elif third_move == "yellow":
      print("You won!")
    else:
      print("GAME OVER")
  else:
    print("Attacked by trout. GAME OVER")
else:
  print("Fall into a hole. GAME OVER")