#Write your code below this line 👇

print(len(input('What is your name?')))









